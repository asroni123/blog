<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class up extends Model
{
    //
}
