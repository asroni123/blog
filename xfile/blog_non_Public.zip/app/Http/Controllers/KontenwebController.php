<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class KontenwebController extends Controller
{
    //Membuat method
    //
  //

  public function homepage()
  {
      return view('homepage');
  }

  public function tambah(){

  }

public function edit()
    {

    }

}
