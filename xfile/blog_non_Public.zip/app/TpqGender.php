<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TpqGender extends Model
{
    //
}
