

<!DOCTYPE html>
<html>
<head>

</head>
<body>

<body >

<h1>Link to Example Cafe </h1>
 
 <div >
 <a href=”index.html” > Starter </a >
 |
 <a href=”menu.html” > Main Courses </a >
 |
 <a href=”recipes.html” > Desserts </a >
 </div > 

<p>This is ... by <a href=" ">Wrox.com </a> </p>	

</body>
</html>