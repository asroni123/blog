<!DOCTYPE html>
<html>
    <head>
        <title>blog</title>
    </head>
    <body>
        <h3>Tampilan</h3>
        <p>Paragraph 1 </p>
        
    </body>

</html><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/blog/resources/views/blog.blade.php ENDPATH**/ ?>